// stats.tsx (Updated with Auth Token Sending)

import { useState, useEffect, useRef } from "react";
import AppLayout from "@/components/layout/AppLayout";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BarChart3, PieChart, LineChart, Calendar, Download, RefreshCw, Filter, ArrowUpDown, Bot } from "lucide-react"; // Added Bot icon
import { supabase } from "@/integrations/supabase/client"; // Assuming supabase client is exported here
import { useAuth } from "@/contexts/AuthContext";
import { useToast } from "@/hooks/use-toast";
import { useQuery } from "@tanstack/react-query";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart as RechartsPieChart,
  Pie,
  Cell,
  LineChart as RechartsLineChart,
  Line,
  Legend,
} from "recharts";
import { useExpenses } from "@/hooks/useExpenses";
import { exportData, setCustomDateRange, viewAllRecommendations } from "@/utils/buttonActions"; // Assuming these exist
import useRealTimeUpdates from "@/hooks/useRealTimeUpdates"; // Assuming this exists

// Type definitions
type ExportFormat = "csv" | "pdf" | "json";

// --- Helper Functions (Keep as is from previous version) ---
const groupExpensesByMonth = (expenses: any[]): { name: string; amount: number }[] => {
  const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const grouped: { [key: string]: number } = {};
  months.forEach(month => { grouped[month] = 0; });
  expenses.forEach(expense => {
    const date = new Date(expense.date);
    if (!isNaN(date.getTime())) {
        const month = months[date.getMonth()];
        grouped[month] += Number(expense.amount) || 0;
    }
  });
  return Object.entries(grouped).map(([name, amount]) => ({ name, amount }));
};

const groupExpensesByCategory = (expenses: any[]): { name: string; value: number }[] => {
  const grouped: { [key: string]: number } = {};
  expenses.forEach(expense => {
    const category = expense.description || "Other"; // Adjust if using category names/IDs
    if (!grouped[category]) { grouped[category] = 0; }
    grouped[category] += Number(expense.amount) || 0;
  });
  return Object.entries(grouped).map(([name, value]) => ({ name, value }));
};

const processSavingsData = (savingsGoals: any[], expenses: any[], timeRange: string) => {
    // Keeping previous logic, but noting that savings calculation needs review
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const savingsData: { name: string; savings: number; goal: number }[] = [];
    const today = new Date();
    let startDate = new Date();

    if (timeRange === "1year") { startDate.setFullYear(today.getFullYear() - 1); }
    else if (timeRange === "6months") { startDate.setMonth(today.getMonth() - 6); }
    else {
         const earliestExpenseDate = expenses.reduce((earliest, exp) => {
            const d = new Date(exp.date);
            return !isNaN(d.getTime()) && d < earliest ? d : earliest;
         }, new Date());
         const earliestGoalDate = savingsGoals.reduce((earliest, goal) => {
             const d = new Date(goal.created_at); // Or deadline?
             return !isNaN(d.getTime()) && d < earliest ? d : earliest;
         }, new Date());
          startDate = earliestExpenseDate < earliestGoalDate ? earliestExpenseDate : earliestGoalDate;
          startDate = startDate < today ? startDate : new Date(today.getFullYear(), 0, 1); // Ensure start date is reasonable
    }

    const monthlySavings: { [key: string]: number } = {};
    const monthlyGoals: { [key: string]: number } = {};
    let currentDate = new Date(startDate);
    currentDate.setDate(1);
    while (currentDate <= today) {
        const monthKey = `${currentDate.getFullYear()}-${currentDate.getMonth()}`;
        monthlySavings[monthKey] = 0; monthlyGoals[monthKey] = 0;
        currentDate.setMonth(currentDate.getMonth() + 1);
    }

    savingsGoals.forEach(goal => {
        const goalDate = goal.deadline ? new Date(goal.deadline) : new Date(goal.created_at); // Use deadline or creation
        if (!isNaN(goalDate.getTime())) {
            const monthKey = `${goalDate.getFullYear()}-${goalDate.getMonth()}`;
            if (monthlyGoals[monthKey] !== undefined) {
                monthlyGoals[monthKey] += Number(goal.target_amount) || 0;
                // Placeholder: using current_amount to show progress trend
                monthlySavings[monthKey] = Math.max(monthlySavings[monthKey], Number(goal.current_amount) || 0);
            }
        }
    });

    Object.keys(monthlySavings).forEach((monthKey) => {
        const [year, month] = monthKey.split('-');
        const date = new Date(Number(year), Number(month));
        if (date >= startDate && date <= today) {
            savingsData.push({ name: months[date.getMonth()], savings: monthlySavings[monthKey], goal: monthlyGoals[monthKey] });
        }
    });
     savingsData.sort((a,b) => months.indexOf(a.name) - months.indexOf(b.name)); // Basic sort
    return savingsData;
};


// --- StatsPage Component ---
const StatsPage = () => {
  const { user } = useAuth(); // Assumes useAuth provides user object with id
  const { expenses, isLoading: isExpensesLoading, refetch } = useExpenses();
  const { toast } = useToast();
  const [timeRange, setTimeRange] = useState<string>("6months");
  const [monthlyData, setMonthlyData] = useState<{ name: string; amount: number }[]>([]);
  const [categoryData, setCategoryData] = useState<{ name: string; value: number }[]>([]);
  const [totalSpent, setTotalSpent] = useState<number>(0);
  const [averageMonthly, setAverageMonthly] = useState<number>(0);
  const [savingsData, setSavingsData] = useState<{ name: string; savings: number; goal: number }[]>([]);
  const [averageSavings, setAverageSavings] = useState<number>(0);

  // --- Chatbot State ---
  const [prompt, setPrompt] = useState<string>("");
  const [chatHistory, setChatHistory] = useState<{ role: "user" | "assistant"; content: string }[]>([]);
  const [isChatLoading, setIsChatLoading] = useState<boolean>(false);
  const chatContainerRef = useRef<HTMLDivElement>(null);

  // --- Chatbot useEffect for Scrolling ---
  useEffect(() => {
    if (chatContainerRef.current) {
      chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
    }
  }, [chatHistory]);

  // --- Chatbot Handler (MODIFIED with Auth Token) ---
  const handlePromptSubmit = async () => {
    const currentPrompt = prompt.trim();
    if (!currentPrompt || isChatLoading) return;

    setIsChatLoading(true);
    const newUserMessage = { role: "user" as const, content: currentPrompt };
    const thinkingMessage = { role: "assistant" as const, content: "Thinking..." };
    setChatHistory((prev) => [...prev, newUserMessage, thinkingMessage]);
    setPrompt("");

    // --- Get Auth Token ---
    let accessToken: string | null = null;
    let assistantResponse = ""; // Initialize here

    try {
      // Attempt to get session/token using the imported supabase client
      const { data: { session }, error: sessionError } = await supabase.auth.getSession();

      if (sessionError) {
        throw new Error(`Supabase session error: ${sessionError.message}`);
      }
      if (session?.access_token) {
        accessToken = session.access_token;
        console.log("Auth token retrieved successfully."); // For debugging
      } else {
        console.error("Chatbot: No active user session found. Cannot send request.");
        assistantResponse = "Error: You seem to be logged out or your session expired. Please log in again.";
        // Update history immediately and stop
        setChatHistory((prev) => {
            const updatedHistory = prev.slice(0, -1); // Remove "Thinking..."
            updatedHistory.push({ role: "assistant", content: assistantResponse });
            return updatedHistory;
        });
        setIsChatLoading(false);
        return; // Stop execution
      }
    } catch (authError: any) {
      console.error("Chatbot: Error getting auth session:", authError);
      assistantResponse = `Error: Could not verify your session. ${authError.message || authError}`;
       // Update history immediately and stop
      setChatHistory((prev) => {
            const updatedHistory = prev.slice(0, -1); // Remove "Thinking..."
            updatedHistory.push({ role: "assistant", content: assistantResponse });
            return updatedHistory;
       });
      setIsChatLoading(false);
      return; // Stop execution
    }

    // --- Call the Backend API (if token was retrieved) ---
    const apiUrl = 'http://localhost:8000/chat';

    try {
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          // --- Include Auth Token ---
          'Authorization': `Bearer ${accessToken}`
        },
        body: JSON.stringify({ query: currentPrompt })
      });

      if (!response.ok) {
        const errorData = await response.json();
        console.error('Error from backend:', response.status, errorData);
        assistantResponse = `Error: ${errorData.detail || 'Failed to get response from assistant.'}`;
      } else {
        const responseData = await response.json();
        assistantResponse = responseData.response;
      }

    } catch (error) {
      console.error('Network error:', error);
      assistantResponse = 'Network error: Could not reach the chatbot service.';
    } finally {
      // Update chat history with the final response (success or error)
      setChatHistory((prev) => {
        const updatedHistory = prev.slice(0, -1); // Remove "Thinking..."
        updatedHistory.push({ role: "assistant", content: assistantResponse });
        return updatedHistory;
      });
      setIsChatLoading(false); // Clear loading state
    }
  }; // End of handlePromptSubmit

  // --- Realtime Updates Hook (Keep as is) ---
  useRealTimeUpdates({ tableName: "expenses", onDataChange: () => { refetch(); }});

  // --- Savings Goals Query (Keep as is) ---
  const { data: savingsGoals, isLoading: isSavingsLoading, error: savingsError } = useQuery({
    queryKey: ['savings_goals', user?.id],
    queryFn: async () => { /* ... query logic ... */
        if (!user?.id) return [];
        const { data, error } = await supabase.from('savings_goals').select('*').eq('user_id', user.id);
        if (error) throw error; return data || [];
     }, enabled: !!user?.id, });

  // --- Error Handling & Data Processing useEffects (Keep as is from previous version) ---
   useEffect(() => { if (savingsError) { /* ... toast logic ... */ } }, [savingsError, toast]);
   useEffect(() => { /* ... expense/savings data processing logic ... */ }, [expenses, timeRange, savingsGoals, isExpensesLoading, isSavingsLoading]);

  // --- Event Handlers (Keep as is) ---
  const handleRefresh = () => { /* ... refresh logic ... */ refetch(); toast({ title: "Data refreshed..."}); };
  const handleTimeRangeChange = (range: string) => { /* ... time range logic ... */ setTimeRange(range); toast({ title: "Time range changed..." }); };
  const handleExport = (format: ExportFormat = "csv") => { exportData(format); };
  const handleCustomRange = () => { const result = setCustomDateRange(); console.log("Custom date range set:", result); };
  const handleViewAllRecommendations = () => { viewAllRecommendations(); };

  // --- Chart Colors (Keep as is) ---
  const COLORS = ['#9b87f5', '#1EAEDB', '#F97316', '#D946EF', '#10B981', '#8B5CF6'];

  // --- JSX Return ---
  return (
    <AppLayout>
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-3xl font-bold flex items-center gap-2 mb-2">
          <BarChart3 className="text-finny-purple" /> Financial Statistics
        </h1>
        <p className="text-muted-foreground">Analyze your financial data and track your progress</p>
      </div>

      {/* Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between mb-6">
         {/* Time Range Badges */}
        <div className="flex flex-wrap gap-2 mb-4 md:mb-0">
             {/* Badges kept as original */}
             <Badge className={`px-4 py-1 cursor-pointer ${timeRange === "6months" ? "bg-finny-purple text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`} onClick={() => handleTimeRangeChange("6months")}>Last 6 Months</Badge>
             <Badge className={`px-4 py-1 cursor-pointer ${timeRange === "1year" ? "bg-finny-purple text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`} onClick={() => handleTimeRangeChange("1year")}>Last Year</Badge>
             <Badge className={`px-4 py-1 cursor-pointer ${timeRange === "all" ? "bg-finny-purple text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`} onClick={() => handleTimeRangeChange("all")}>All Time</Badge>
        </div>
        {/* Action Buttons */}
        <div className="flex gap-2">
             {/* Buttons kept as original */}
             <Button variant="outline" size="sm" className="flex items-center gap-1" onClick={handleCustomRange}><Calendar size={14} /> Custom Range</Button>
             <Button variant="outline" size="sm" className="flex items-center gap-1" onClick={() => handleExport("csv")}><Download size={14} /> Export</Button>
             <Button variant="outline" size="sm" className="flex items-center gap-1" onClick={handleRefresh}><RefreshCw size={14} /> Refresh</Button>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          {/* Monthly Spending Card */}
          <Card>
             {/* ... content kept as original ... */}
              <CardHeader><CardTitle className="text-lg flex items-center gap-2"><BarChart3 className="text-finny-purple h-5 w-5" /> Monthly Spending</CardTitle><CardDescription>Track your expenses over time</CardDescription></CardHeader>
              <CardContent className="pt-0"><div className="h-64">{/* ... chart rendering logic ... */}</div><div className="mt-4">{/* ... totals ... */}</div></CardContent>
          </Card>
          {/* Spending by Category Card */}
           <Card>
               {/* ... content kept as original ... */}
                <CardHeader><CardTitle className="text-lg flex items-center gap-2"><PieChart className="text-finny-blue h-5 w-5" /> Spending by Category</CardTitle><CardDescription>Where your money is going</CardDescription></CardHeader>
                <CardContent className="pt-0"><div className="h-64 flex justify-center">{/* ... chart rendering logic ... */}</div></CardContent>
           </Card>
           {/* Savings Trend Card */}
           <Card>
                {/* ... content kept as original ... */}
                 <CardHeader><CardTitle className="text-lg flex items-center gap-2"><LineChart className="text-finny-green h-5 w-5" /> Savings Trend</CardTitle><CardDescription>Monthly savings vs. goal</CardDescription></CardHeader>
                 <CardContent className="pt-0"><div className="h-64">{/* ... chart rendering logic ... */}</div><div className="mt-4">{/* ... totals ... */}</div></CardContent>
           </Card>
      </div>

      {/* --- Chatbot Card (MODIFIED with Auth Integration) --- */}
      <Card className="mb-8">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
             <Bot className="text-finny-purple" /> {/* Using Bot icon */}
            Finny Assistant
          </CardTitle>
          <CardDescription>
            Chat with your personal financial assistant for insights and advice. <br/>
            <span className="text-xs italic"> Use 'DB:' prefix for questions about your data (e.g., 'DB: show my income'). Ask general questions normally.</span>
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="flex flex-col gap-4">
            {/* Chat Container */}
            <div
              ref={chatContainerRef}
              className="h-64 overflow-y-auto bg-gray-50 rounded-lg p-4 flex flex-col gap-3 border border-gray-200"
            >
              {chatHistory.length === 0 ? (
                <p className="text-muted-foreground text-center text-sm">
                  Ask a question like "What is a good savings rate?" or "DB: show my expenses this month"
                </p>
              ) : (
                chatHistory.map((message, index) => (
                  <div
                    key={index}
                    className={`flex ${message.role === "user" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-[75%] p-3 rounded-lg text-sm shadow-sm ${
                        message.role === "user"
                          ? "bg-finny-purple text-white"
                          : message.content.startsWith("Error:") || message.content.startsWith("Network error:")
                          ? "bg-red-100 text-red-700 border border-red-200"
                          : message.content === "Thinking..."
                          ? "bg-gray-200 text-gray-600 animate-pulse"
                          : "bg-white text-gray-800 border border-gray-200"
                      }`}
                    >
                      {/* Use whitespace-pre-wrap to respect newlines from the LLM */}
                      <p style={{ whiteSpace: 'pre-wrap' }}>{message.content}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
            {/* Prompt Input */}
            <div className="flex gap-2 items-center">
              <input
                type="text"
                placeholder="Ask about your finances..."
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                onKeyPress={(e) => {if (e.key === "Enter" && !isChatLoading) {handlePromptSubmit();}}}
                className="flex-1 p-3 rounded-lg border border-gray-300 focus:outline-none focus:ring-2 focus:ring-finny-purple text-sm"
                disabled={isChatLoading} // Disable input while loading
              />
              <Button
                onClick={handlePromptSubmit}
                className="bg-finny-purple hover:bg-finny-purple/90 text-white px-5 py-3"
                disabled={isChatLoading || !prompt.trim()} // Disable if loading or input empty
              >
                {isChatLoading ? "Asking..." : "Ask"} {/* Change button text */}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
      {/* --- End of Chatbot Card --- */}

      {/* Recent Transactions Analysis Card (Keep as is) */}
       <div className="mb-8">
            {/* ... existing transaction analysis table structure ... */}
             <div className="flex items-center justify-between mb-4"><h2 className="text-xl font-bold">Recent Transactions Analysis (Placeholder)</h2></div>
             <Card><CardContent className="p-0"><div className="overflow-x-auto">{/* Table kept as original */}</div></CardContent></Card>
       </div>

      {/* Financial Health & Recommendations Grid (Keep as is) */}
       <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
           {/* Financial Health Score Card */}
           <Card>{/* ... content kept as original ... */}</Card>
           {/* Recommendations Card */}
           <Card>{/* ... content kept as original ... */}</Card>
       </div>
    </AppLayout>
  );
};

export default StatsPage;