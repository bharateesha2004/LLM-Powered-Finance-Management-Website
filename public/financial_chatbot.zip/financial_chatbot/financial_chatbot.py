# chatbot_api.py
# Description: FastAPI backend for a financial chatbot using LangChain, Gemini, and Supabase.
# Includes user authentication via Supabase token and routes queries.

# --- Core Libraries ---
import os
import re
import warnings
from dotenv import load_dotenv

# --- LangChain & AI ---
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_community.utilities import SQLDatabase
from langchain_community.agent_toolkits import SQLDatabaseToolkit
from langchain.agents import create_sql_agent, AgentExecutor

# --- Database ---
from sqlalchemy import create_engine # Although not used directly after SQLDatabase init, keep for potential future use

# --- Web Framework & Utils ---
import uvicorn
from fastapi import FastAPI, HTTPException, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional

# --- Supabase Auth ---
from supabase import create_client, Client

print("--- Chatbot API Server Loading ---")
print("Loading environment variables and libraries...")

# --- Environment Variable Loading ---
load_dotenv()

# --- Configuration ---
# Google AI
GOOGLE_API_KEY = os.getenv("GOOGLE_API_KEY")
# Supabase Database (Using Pooler based on previous debugging)
SUPABASE_DB_PASSWORD = os.getenv("SUPABASE_DB_PASSWORD")
SUPABASE_DB_HOST = os.getenv("SUPABASE_DB_HOST") # Should be Pooler host
SUPABASE_DB_PORT = os.getenv("SUPABASE_DB_PORT", "6543") # Pooler port
SUPABASE_DB_USER = os.getenv("SUPABASE_DB_USER", "postgres")
SUPABASE_DB_NAME = os.getenv("SUPABASE_DB_NAME", "postgres")
# Supabase Auth
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_ANON_KEY = os.getenv("SUPABASE_ANON_KEY")

# --- Critical Configuration Validation ---
required_env_vars = {
    "GOOGLE_API_KEY": GOOGLE_API_KEY,
    "SUPABASE_DB_PASSWORD": SUPABASE_DB_PASSWORD,
    "SUPABASE_DB_HOST": SUPABASE_DB_HOST,
    "SUPABASE_URL": SUPABASE_URL,
    "SUPABASE_ANON_KEY": SUPABASE_ANON_KEY,
}
missing_vars = [k for k, v in required_env_vars.items() if not v]
if missing_vars:
    print(f"❌ FATAL ERROR: Missing required environment variables: {', '.join(missing_vars)}")
    print("   Please ensure these are set in your .env file.")
    exit() # Stop execution if critical config is missing

# Set Google API Key for LangChain libraries
os.environ["GOOGLE_API_KEY"] = GOOGLE_API_KEY

print("✅ Environment variables loaded.")
print(f"   Using DB: postgresql+psycopg2://{SUPABASE_DB_USER}:***@{SUPABASE_DB_HOST}:{SUPABASE_DB_PORT}/{SUPABASE_DB_NAME}")
print(f"   Supabase Auth URL: {SUPABASE_URL}")

# --- Global Variables for Initialized Components ---
llm: Optional[ChatGoogleGenerativeAI] = None
db: Optional[SQLDatabase] = None
toolkit: Optional[SQLDatabaseToolkit] = None
agent_executor: Optional[AgentExecutor] = None
supabase_client: Optional[Client] = None
_SQL_AGENT_SUFFIX: str = "" # Placeholder for agent instructions

# --- Initialization Block (Run Once on Startup) ---
try:
    # 1. Initialize Supabase Client (for Auth)
    print("Initializing Supabase client...")
    supabase_client = create_client(SUPABASE_URL, SUPABASE_ANON_KEY)
    print("✅ Supabase Client Initialized.")

    # 2. Initialize LLM
    print("Initializing LLM (gemini-1.5-flash-latest)...")
    llm = ChatGoogleGenerativeAI(
        model="gemini-1.5-flash-latest",
        temperature=0.1, # Lower temperature for potentially more factual/SQL related tasks
        # safety_settings=... # Optional: Configure safety settings
    )
    print("✅ LLM Initialized.")

    # 3. Create Database Connection URI
    print("Creating DB Connection URI...")
    db_uri = f"postgresql+psycopg2://{SUPABASE_DB_USER}:{SUPABASE_DB_PASSWORD}@{SUPABASE_DB_HOST}:{SUPABASE_DB_PORT}/{SUPABASE_DB_NAME}"
    print("✅ DB URI Created.")

    # 4. Initialize LangChain SQLDatabase
    # Ensure SQLAlchemy is pinned to a compatible version (<2.0.31 worked before)
    print("Connecting to Database via SQLAlchemy...")
    include_tables = ["profiles", "expense_categories", "expenses", "savings_goals"] # Tables agent can query
    db = SQLDatabase.from_uri(
        db_uri,
        include_tables=include_tables,
        sample_rows_in_table_info=2 # Provides schema and sample rows to the LLM
    )
    print(f"✅ SQLDatabase connection established.")
    print(f"   Agent has access to tables: {', '.join(db.get_usable_table_names())}")

    # 5. Define Agent Instructions (Suffix)
    # Note: Tells the agent to expect the UserID prepended to the input query.
    print("Defining Agent Suffix/Instructions...")
    _SQL_AGENT_SUFFIX = """
TOOLS:
------
You have access to ONE tool named `sql_db_query` for querying the user's personal financial database. Use this tool ONLY as instructed below.

USER CONTEXT & SECURITY MANDATE (for SQL Tool):
-----------------------------------------------
The user's query about their personal data will be prefixed with 'UserID [USER_ID_UUID]:'.
**You MUST extract the USER_ID_UUID from the beginning of the input query.**
**You MUST use this extracted USER_ID_UUID to filter queries** on relevant tables:
Use `WHERE id = '[EXTRACTED_USER_ID_UUID]'` for `public.profiles`.
Use `WHERE user_id = '[EXTRACTED_USER_ID_UUID]'` for `public.expense_categories`, `public.expenses`, `public.savings_goals`.
**CRITICAL (SQL Tool): Do NOT query data for any other user_id.** If the UserID prefix is missing for a database query, state that you cannot proceed without user context.

*** TASK ROUTING & RESPONSE INSTRUCTIONS ***
--------------------------------------------
**1. Analyze the User's Query (the part AFTER the 'UserID [...]' prefix if present):** Determine the *type* of question:
    * **Type A: Personal Data Query:** Does it ask about the user's *specific* financial details stored in the database? These require using the `sql_db_query` tool.
    * **Type B: General Finance Question:** Is it a request for general financial knowledge, definitions, advice, tips, or explanations? These do **NOT** use the database tool.

**2. Execute Based on Type:**
    * **If Type A (Personal Data):**
        * Extract the USER_ID_UUID from the input prefix.
        * Use the `sql_db_query` tool.
        * Construct an accurate PostgreSQL query, ensuring you include the **mandatory filter using the extracted user ID**. Query only necessary columns.
        * Formulate your response based *only* on the data returned by the query. Handle errors gracefully.
    * **If Type B (General Finance):**
        * **DO NOT use the `sql_db_query` tool.**
        * Answer the question directly using your own extensive financial knowledge base.
        * **Keep your answer concise and focused, aiming for a maximum of 4 lines.**
        * DO NOT just say "I don't know".

**3. General Response Style:** Maintain a clear, encouraging, and advisory tone. Be accurate.
"""
    print("✅ Agent Suffix Defined.")

    # 6. Create SQL Toolkit
    print("Creating SQL Toolkit...")
    toolkit = SQLDatabaseToolkit(db=db, llm=llm)
    print("✅ SQL Toolkit Created.")

    # 7. Create Agent Executor
    print("Creating Agent Executor ('tool-calling')...")
    agent_executor = create_sql_agent(
        llm=llm,
        toolkit=toolkit,
        verbose=True, # Logs agent steps to server console - helpful for debugging
        agent_type="tool-calling", # Use the LLM's native tool calling
        suffix=_SQL_AGENT_SUFFIX,
        handle_parsing_errors=True # Attempts to fix LLM output parsing errors
    )
    print("✅ Agent Executor Created.")

except Exception as e:
    print(f"❌ FATAL ERROR during component initialization: {e}")
    # Set components to None to prevent server start
    llm = None
    db = None
    toolkit = None
    agent_executor = None
    supabase_client = None

# --- FastAPI Application Setup ---
print("Setting up FastAPI application...")
app = FastAPI(
    title="Financial Chatbot API",
    description="API endpoint for the personal finance chatbot using LangChain and Gemini.",
    version="1.0.0",
)

# CORS Configuration
# Allows the frontend (running on different origins like localhost:3000) to call this API
origins = [
    "http://localhost",
    "http://localhost:3000", # Common React dev port
    "http://localhost:5173", # Common Vite dev port
    "http://localhost:8080",
    # Add the URL of your deployed frontend application here later
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["POST", "GET"], # Allow POST for chat, GET for root
    allow_headers=["*"], # Allow all headers, including Authorization
)

# --- API Request/Response Models ---
class ChatRequest(BaseModel):
    query: str

class ChatResponse(BaseModel):
    response: str

# --- API Endpoints ---
@app.get("/")
async def root():
    """ Basic endpoint to check if the API is running. """
    return {"message": "Financial Chatbot API is running. Use the /chat endpoint (POST) with 'Authorization: Bearer <token>' header."}

@app.post("/chat", response_model=ChatResponse)
async def handle_chat(
    request: ChatRequest,
    Authorization: Optional[str] = Header(None) # Extract 'Authorization' header
):
    """
    Handles chat requests.
    1. Validates Supabase JWT token from Authorization header.
    2. Extracts user ID.
    3. Routes query to SQL agent (if prefixed with 'DB:') or General LLM.
    4. Returns the chatbot's response.
    """
    user_query = request.query
    print("-" * 50)
    print(f"Received request for /chat")
    print(f"Raw Query: {user_query}")

    # Check if components initialized correctly on startup
    if not agent_executor or not llm or not supabase_client:
         print("❌ ERROR: Chatbot components not initialized during startup.")
         raise HTTPException(status_code=503, detail="Chatbot service is not ready.") # 503 Service Unavailable

    # --- Step 1: Authentication & User ID Extraction ---
    if Authorization is None or not Authorization.startswith("Bearer "):
        print("❌ ERROR: Missing or incorrectly formatted Authorization header.")
        raise HTTPException(status_code=401, detail="Unauthorized: Missing or invalid Authorization header.")

    token = Authorization.split("Bearer ")[1]
    validated_user_id = None
    try:
        print("   Validating auth token...")
        # Use Supabase client to get user info from the provided token
        user_response = await supabase_client.auth.get_user(token)
        user = user_response.user
        if user and user.id:
            validated_user_id = str(user.id) # Ensure it's a string
            print(f"   ✅ Token validated for User ID: {validated_user_id}")
        else:
             print("❌ ERROR: Auth token is invalid or user could not be retrieved.")
             raise HTTPException(status_code=401, detail="Unauthorized: Invalid token or user not found.")
    except Exception as auth_error:
         print(f"❌ ERROR: Supabase auth validation failed: {auth_error}")
         # Log the specific error for debugging, but return a generic auth error
         raise HTTPException(status_code=401, detail="Unauthorized: Authentication error.")

    # --- Step 2: Routing and Processing ---
    output = "An unexpected error occurred." # Default response
    try:
        # Check for 'DB:' prefix (case-insensitive, ignoring leading space)
        if re.match(r"^\s*DB:", user_query, re.IGNORECASE):
            # --- Route to Database Agent ---
            print(f"   Routing to Database Agent for user: {validated_user_id}")
            # Strip prefix and trim whitespace
            db_query = re.sub(r"^\s*DB:", "", user_query, flags=re.IGNORECASE).strip()

            if not db_query:
                output = "Please provide a specific question about your data after 'DB:'."
            else:
                # Augment the input query with the validated User ID for the agent
                augmented_input = f"UserID {validated_user_id}: {db_query}"
                print(f"   Augmented agent input: \"{augmented_input}\"")
                agent_input = {"input": augmented_input}

                # Invoke the SQL agent asynchronously
                response = await agent_executor.ainvoke(agent_input)
                output = response.get('output', "Sorry, I couldn't retrieve or process the database information.")

        else:
            # --- Route to General LLM ---
            print("   Routing to General LLM for concise answer...")
            # Prepare prompt for general knowledge, enforcing conciseness
            general_prompt = f"Answer the following financial question concisely, providing a helpful summary within a maximum of 4 lines:\n\nQuestion: {user_query}\n\nAnswer:"

            # Invoke the base LLM asynchronously
            llm_response = await llm.ainvoke(general_prompt)

            # Extract content from response (might be string or message object)
            if hasattr(llm_response, 'content'):
                output = llm_response.content
            else:
                output = str(llm_response)

    except Exception as e:
        print(f"❌ Error processing query for user {validated_user_id}: {e}")
        # Log the full error for debugging on the server
        # Return a generic error to the client
        raise HTTPException(status_code=500, detail="An internal error occurred while processing your request.")

    # --- Step 3: Return Response ---
    print(f"   Responding with (first 100 chars): {output[:100]}...")
    print("-" * 50)
    return ChatResponse(response=output)


# --- Main Execution Block ---
if __name__ == "__main__":
    # Check if all critical components were initialized successfully
    if llm and db and toolkit and agent_executor and supabase_client:
        print("✅ All components initialized successfully.")
        print("--- Starting FastAPI Server ---")
        # Listen on all interfaces (0.0.0.0) to be accessible on the local network
        uvicorn.run(app, host="0.0.0.0", port=8000, log_level="info") # Use log_level info
    else:
        print("❌ FastAPI server cannot start due to initialization errors. Please check logs.")